# ⚔️ OuterRealms | 2D Roguelike RPG

> *A survival RPG inspired by "Vampire Survivors" that implements core Computer Science algorithms into gameplay mechanics.*

### 📖 About the Game
**OuterRealms** is a 2D top-down rogue-like game where players must survive endless waves of enemies. Beyond just being a game, this project serves as a technical demonstration of **Data Structures and Algorithms**.

The core feature is the **Equipment Merging System**, which utilizes a custom **Merge Sort algorithm** to organize inventory and automatically combine duplicate items into stronger gear in real-time.

---

### 📸 Game Gallery

| **Main Menu** | **Gameplay Action** | **Character Select** |
| :---: | :---: | :---: |
| ![Main Menu](main-menu.png) | ![Gameplay](gameplay.png) | ![Selection](map.png) |

---

### ✨ Key Features
* **⚔️ Auto-Merge Inventory:** Items collected are automatically sorted and merged into higher-tier equipment using efficient sorting algorithms.
* **🧟 Endless Waves:** Procedural enemy spawning that increases in difficulty over time.
* **🛡️ RPG Progression:** Level up characters, unlock new skills, and upgrade stats.
* **🎨 Pixel Art Style:** Custom assets designed using Aseprite and Photoshop.

---

### 🛠️ Built With
* **Language:** Java / C++
* **Game Logic:** Custom Game Loop & Physics
* **Algorithms:** Merge Sort (Inventory Management)
* **Art & Design:** Photoshop, Aseprite, LDtk

---

### 🚀 How to Play
**Important:** The game files are compressed to save space. You must extract them before playing.

1.  Clone or Download this repository.
2.  Locate the **`.rar`** archive file inside the main folder.
3.  **Right-click and "Extract Here" (Unzip) the RAR file.**
4.  **After unzipping, compile all files into a single folder accordingly.**
5.  Run the executable file to start the game.

---

### 📬 Contact
**John Andrae Tuaño**
* [LinkedIn](https://www.linkedin.com/in/john-andrae-tuano/)
* [Email](mailto:johnandrae.tuano@gmail.com)
